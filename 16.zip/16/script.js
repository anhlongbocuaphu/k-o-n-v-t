function showLove() {
  document.getElementById("gift-screen").classList.add("hidden");
  const loveScreen = document.getElementById("love-screen");
  loveScreen.classList.remove("hidden");

  // Hiệu ứng cho ảnh
  const images = document.querySelectorAll('.lover-img');
  images.forEach((img, i) => {
    img.style.animationDelay = `${i * 0.5}s`;
  });

  // Hiệu ứng cho text
  const messages = document.querySelectorAll('#messages p');
  messages.forEach((msg, i) => {
    msg.style.setProperty('--delay', `${i * 4 + 2}s`);
  });

  // Tạo hiệu ứng trái tim
  setTimeout(createHearts, 1000);
}

function createHearts() {
  const heartsContainer = document.querySelector('.hearts');
  const colors = ['#ff69b4', '#ff1493', '#ff007f', '#ff69b4'];
  
  setInterval(() => {
    const heart = document.createElement('div');
    heart.classList.add('heart');
    heart.style.left = Math.random() * 100 + "vw";
    heart.style.fontSize = Math.random() * 20 + 15 + "px";
    heart.style.color = colors[Math.floor(Math.random() * colors.length)];
    heart.style.animationDuration = Math.random() * 2 + 3 + "s";
    heart.innerText = "💗";
    heartsContainer.appendChild(heart);
    
    setTimeout(() => heart.remove(), 5000);
  }, 300);
}
